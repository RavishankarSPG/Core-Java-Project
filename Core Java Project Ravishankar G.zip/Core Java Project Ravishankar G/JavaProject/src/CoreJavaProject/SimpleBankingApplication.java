//Simple Banking Application
package CoreJavaProject;
import java.util.Scanner;

class Bank {
	String Account_Holder_Name,First_Name,Last_Name;
	long Account_Number;
	double Deposit,Withdraw,Balance;
	
	Scanner ah = new Scanner(System.in);
	Scanner an = new Scanner(System.in);
	Scanner sc = new Scanner(System.in);
	
	void account_holder_name()
	{
		System.out.println("Enter Account Holder Name ");
		System.out.print("First Name: ");
		First_Name=ah.nextLine();
		System.out.print("Last Name: ");
		Last_Name=ah.nextLine();
		Account_Holder_Name=First_Name+" "+Last_Name;
		System.out.println();
		}
	
	void account_number()
	{
		System.out.print("Enter Account Number: ");
		Account_Number=an.nextLong();
		System.out.println();
		}
			
	void deposit() 
	{
		System.out.print("Deposit: Rs.");
		Deposit=sc.nextDouble();
		System.out.println();
		}
	
	void withdraw()
	{
		System.out.print("Withdraw: Rs.");
		Withdraw=sc.nextDouble();
		
		if((Withdraw>Deposit)&&(Deposit>0))
		{
			System.out.println("Cannot withdraw, the deposit is less than withdraw");
			}
		else if((Deposit==0)&&(Withdraw>0))
		{
			System.out.println("Cannot withdraw, the deposit is 0");
			}
		System.out.println();
		}
	
	void balance()
	{
		Balance=Deposit-Withdraw;
		
		if(Deposit>Withdraw)
		{
			System.out.println("Balance: Rs."+Balance);
			}
		else if((Withdraw>Deposit)&&(Deposit>0))
		{
			System.out.println("Balance: Rs."+Deposit);
			}
		else if(Deposit==Withdraw)
		{
			System.out.println("Balance: Rs."+Balance);
			}
		else if((Deposit==0)&&(Withdraw>0))
		{
			System.out.println("Balance: Rs."+Deposit);
			}
		System.out.println();
		}
	
	void account_information() 
	{
		System.out.println();
		System.out.println("Account Information");
		System.out.println("===================");
		System.out.println("Account Holder Name: "+Account_Holder_Name);
		System.out.println("Account Number: "+Account_Number);
		System.out.println("Deposit: Rs."+Deposit);
		
		if (Deposit>Withdraw)
		{
			System.out.println("Withdraw: Rs."+Withdraw);
			}
		else if((Withdraw>Deposit)&&(Deposit>0)) 
		{
			System.out.println("Cannot withdraw Rs."+Withdraw+", the deposit is less than withdraw");
			}
		else if(Deposit==Withdraw) 
		{
			System.out.println("Withdraw: Rs."+Withdraw);
			}
		else if((Deposit==0)&&(Withdraw>0))
		{
			System.out.println("Cannot withdraw Rs."+Withdraw+", the deposit is 0");
			}
		
		if(Deposit>Withdraw) 
		{
			System.out.println("Balance: Rs."+Balance);
			}
		else if((Withdraw>Deposit)&&(Deposit>0))
		{
			System.out.println("Balance: Rs."+Deposit);
			}
		else if(Deposit==Withdraw)
		{
			System.out.println("Balance: Rs."+Balance);
			}
		else if((Deposit==0)&&(Withdraw>0))
		{
			System.out.println("Balance: Rs."+Deposit);
			}
		System.out.println();
		}
	}

public class SimpleBankingApplication 
{
	public static void main(String[] args)
	{
		int step;
		Bank ob=new Bank();	
		try (Scanner st = new Scanner(System.in))
		{
			while(true) 
			{
				System.out.println("    Enter the step    ");
				System.out.println("----------------------");
				System.out.println("1.Account Holder Name");
				System.out.println("2.Account Number");
				System.out.println("3.Deposit");
				System.out.println("4.Withdraw");
				System.out.println("5.Balance");
				System.out.println("6.Account Information");
				System.out.println("7.Exit");
									
				step=st.nextInt();
				
				switch(step)
				{
				case 1:
					ob.account_holder_name();
					break;
				case 2:
					ob.account_number();
					break;
				case 3:
					ob.deposit();
					break;
				case 4:
					ob.withdraw();
					break;
				case 5:
					ob.balance();
					break;
				case 6:
					ob.account_information();
					break;
				case 7:
					System.out.println("Exit..");
					System.exit(0);
					break;
					default:
						System.out.println("Invalid");
						}
				}
		}
	}
}
